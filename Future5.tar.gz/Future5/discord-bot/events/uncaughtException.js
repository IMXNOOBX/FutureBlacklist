module.exports.run = async (client, error) => {
    client.log.error(`[BOT] | Uncaught Exception Error: ${error}`);   
}    