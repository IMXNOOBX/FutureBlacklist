module.exports.run = async (client, info) => {
    client.log.warn(`[WARN] | Client's WebSocket Warning: ${info}`);
}    