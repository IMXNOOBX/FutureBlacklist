module.exports.run = async (client, guild) => {
    client.log.console(`[BOT] | i'v been removed from a guild: ${guild.name}`);
}