module.exports.run = async (client) => {
  client.log.console(
    `[BOT] | Username: ${client.user.tag} | Guilds: ${client.guilds.cache.size} servers | Users: ${client.users.cache.size} total users`
  );
  client.user.setStatus("dnd"); // online, idle, dnd, invisible

  var _total  = 0
  var _modders = 0
  var _advertisers = 0

  var statuses = [
    `${_total} Total Players`,
    `${_modders} Modders`,
    `${_advertisers} Advertisers`,
    `${client.guilds.cache.size} Guilds`,
    `${client.users.cache.size} Users`,
    `github.com/IMXNOOBX`,
  ];

  function updateValues() {
    client.con.query(`SELECT COUNT(*) FROM PLAYERS;`, function (error, total, fields) {
      _total = total[0]['COUNT(*)']
    });
    client.con.query(`SELECT COUNT(*) FROM PLAYERS WHERE modder=1;`, function (error, modders, fields) {
      _modders = modders[0]['COUNT(*)']
    });
    client.con.query(`SELECT COUNT(*) FROM PLAYERS WHERE advertiser=1;`, function (error, advertiser, fields) {
      _advertisers = advertiser[0]['COUNT(*)']
    });
  }

  setInterval(() => {
    updateValues()
  }, 60 * 60 * 1000);

  client.user.setActivity("Starting bot...", { type: client.discord.ActivityType.Competing });
  updateValues()
  setInterval(() => {
    // Weird bug
    statuses[0] = `${_total} Total Players`
    statuses[1] = `${_modders} Modders`
    statuses[2] = `${_advertisers} Advertisers`

    const status = statuses[Math.floor(Math.random() * statuses.length)];
    client.user.setActivity(status, { type: client.discord.ActivityType.Watching });
  }, 60 * 1000);
};
