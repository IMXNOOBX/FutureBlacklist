module.exports.run = async (client, error) => {
    client.log.console(`[BOT] | Client's WebSocket Error: ${error}`);   
}    