module.exports.run = async (client, error) => {
    client.log.error(`[BOT] | Unhandled Rejection Error: ${error}`);
}    