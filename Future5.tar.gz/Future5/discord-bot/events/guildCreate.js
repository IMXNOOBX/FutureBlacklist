module.exports.run = async (client, guild) => {
    client.log.console(`[BOT] | Im in a new guild: ${guild.name}`);   
}